#ifndef CHACAPK_CALC_ENTRY_IJ_H_INCLUDED
#define CHACAPK_CALC_ENTRY_IJ_H_INCLUDED

extern double cHACApK_entry_ij(
  int i,
  int j,
  int i_bemv);

#endif // CHACAPK_CALC_ENTRY_IJ_H_INCLUDED
