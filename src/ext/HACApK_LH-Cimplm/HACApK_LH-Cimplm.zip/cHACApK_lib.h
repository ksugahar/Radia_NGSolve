#ifndef CHACAPK_LIB_H_INCLUDED
#define CHACAPK_LIB_H_INCLUDED

extern int cHACApK_med3(
  int nl,
  int nr,
  int nlr2);

#endif // CHACAPK_LIB_H_INCLUDED
